# Ket - App Mobile para Cálculos no Supermercado
Case Study UX/UI por Matheus Lemes (EBAC)

## Como Rodar Localmente:
1. Instale as dependências: npm install
2. Inicie o servidor de desenvolvimento: npm run dev
3. Acesse no navegador: http://localhost:3000

## Assets para Behance:
- Os mockups em alta resolução estão disponíveis na pasta /src/assets/images
- Toda a documentação e heurísticas de usabilidade estão em /src/components/CaseStudyModal.tsx
